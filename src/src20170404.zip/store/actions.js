// 规定事件的名称
import * as types from './types'

export default {

}