// 规定 各种事件的状态  方法常量值，统一处理在这里，一般都是业务字符串常量。
// 增加
export const INCREMENT = 'INCREMENT';
// 减少
export const DECREMENT = 'DECREMENT';

// 请求之前加载动画
export const SHOWLOAGING = 'SHOWLOAGING';

export const HIDELOADING = 'HIDELOADING';

// 用户信息
// 更新用户信息
export const UPDATEUSERINFO = 'UPDATEUSERINFO';