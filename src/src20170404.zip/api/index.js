// 将文件按照模块的形式导出
module.exports =  {
	ajax: require('./http.js')
};