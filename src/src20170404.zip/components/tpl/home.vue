<template>
    <div>
        <span>主页</span>
    </div> 
</template>