// 不同功能模块的路由应代码分离
import msgRoutes from './msg'
// import authRoutes from './auth'

export default {
  msgRoutes
}
