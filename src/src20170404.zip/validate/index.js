export default  {
	http: require('./vee-validate.js')
};