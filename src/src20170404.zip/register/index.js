// 所有的请求
// import {
// 	request
// } from '../config/';
// 封装的  axios
import {
	ajax
} from '../util/';

export default {
	// apis: request,
	// ajax: ajax
};