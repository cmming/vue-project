<template>
    <!--常用表单元素样式-->
    <!--通用导航条 -->
    <div>
        <div class="error-wrapper">
            <div class="error-inner">
                <div class="error-type animated">404</div>
                <h1>页面不存在</h1>
                <p>
                    你访问的页面发生错误，请联系网站管理员
                </p>
                <div class="m-top-md">
                    <a href="#/manager" class="btn btn-default btn-lg text-upper">返回主页</a>
                </div>
            </div>
            <!-- ./error-inner -->
        </div>
        <!-- ./error-wrapper -->
    </div>
</template>